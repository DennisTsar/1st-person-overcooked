using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum FoodType
{
    Cookable,
    Cuttable,
    Heatable,
    Final,
    None,
}